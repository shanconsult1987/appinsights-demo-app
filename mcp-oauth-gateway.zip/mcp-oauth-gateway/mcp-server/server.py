from fastapi import FastAPI

app = FastAPI(title="Custom MCP Server")

@app.get("/mcp")
async def mcp_root():
    return {
        "name": "Custom MCP Server",
        "version": "1.0.0",
        "capabilities": [
            "tools",
            "prompts",
            "resources"
        ]
    }

@app.get("/tools")
async def tools():
    return {
        "tools": [
            {
                "name": "weather",
                "description": "Returns weather information"
            }
        ]
    }
