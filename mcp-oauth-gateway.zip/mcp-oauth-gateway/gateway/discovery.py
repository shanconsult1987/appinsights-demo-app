from fastapi import APIRouter
from os import getenv

router = APIRouter()

BASE_URL = getenv("BASE_URL")

@router.get("/.well-known/openid-configuration")
async def openid_configuration():
    return {
        "issuer": BASE_URL,
        "authorization_endpoint": f"{BASE_URL}/authorize",
        "token_endpoint": f"{BASE_URL}/token",
        "jwks_uri": f"{BASE_URL}/jwks",
        "registration_endpoint": f"{BASE_URL}/register",
        "response_types_supported": ["code"],
        "subject_types_supported": ["public"],
        "id_token_signing_alg_values_supported": ["RS256"],
        "scopes_supported": ["openid", "profile", "email"],
        "token_endpoint_auth_methods_supported": ["client_secret_post"]
    }
