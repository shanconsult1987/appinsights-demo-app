from fastapi import APIRouter, Request
from authlib.integrations.starlette_client import OAuth
from os import getenv
import httpx

router = APIRouter()

oauth = OAuth()

TENANT_ID = getenv("TENANT_ID")
CLIENT_ID = getenv("CLIENT_ID")
CLIENT_SECRET = getenv("CLIENT_SECRET")
REDIRECT_URI = getenv("REDIRECT_URI")

MICROSOFT_DISCOVERY = (
    f"https://login.microsoftonline.com/"
    f"{TENANT_ID}/v2.0/.well-known/openid-configuration"
)

oauth.register(
    name="microsoft",
    server_metadata_url=MICROSOFT_DISCOVERY,
    client_id=CLIENT_ID,
    client_secret=CLIENT_SECRET,
    client_kwargs={"scope": "openid profile email"}
)

@router.get("/authorize")
async def authorize(request: Request):
    redirect_uri = REDIRECT_URI
    return await oauth.microsoft.authorize_redirect(request, redirect_uri)

@router.get("/callback")
async def callback(request: Request):
    token = await oauth.microsoft.authorize_access_token(request)
    return token

@router.post("/token")
async def token_exchange(request: Request):
    form = await request.form()

    async with httpx.AsyncClient() as client:
        response = await client.post(
            f"https://login.microsoftonline.com/{TENANT_ID}/oauth2/v2.0/token",
            data={
                "client_id": CLIENT_ID,
                "client_secret": CLIENT_SECRET,
                "grant_type": "authorization_code",
                "code": form.get("code"),
                "redirect_uri": REDIRECT_URI
            }
        )

    return response.json()
