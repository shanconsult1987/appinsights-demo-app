from fastapi import FastAPI
from dotenv import load_dotenv
from discovery import router as discovery_router
from dcr import router as dcr_router
from auth import router as auth_router

load_dotenv()

app = FastAPI(title="MCP OAuth Gateway")

app.include_router(discovery_router)
app.include_router(dcr_router)
app.include_router(auth_router)

@app.get("/")
async def root():
    return {"status": "running"}
