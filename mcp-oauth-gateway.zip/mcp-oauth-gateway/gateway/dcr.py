from fastapi import APIRouter
import uuid

router = APIRouter()

registered_clients = {}

@router.post("/register")
async def register_client(payload: dict):
    client_id = str(uuid.uuid4())
    client_secret = str(uuid.uuid4())

    registered_clients[client_id] = {
        "client_secret": client_secret,
        "payload": payload
    }

    return {
        "client_id": client_id,
        "client_secret": client_secret,
        "token_endpoint_auth_method": "client_secret_post",
        "grant_types": ["authorization_code"],
        "response_types": ["code"]
    }
