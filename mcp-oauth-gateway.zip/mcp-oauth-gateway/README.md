# MCP OAuth Gateway for Copilot Studio + Entra ID

Working reference architecture for:

Copilot Studio MCP Client
    -> OAuth2/OIDC Gateway
    -> Microsoft Entra ID
    -> Custom MCP Server

## Features

- OIDC Discovery
- OAuth2 Authorization
- Token Exchange
- Dynamic Client Registration (DCR)
- MCP endpoint support
